from django.contrib import admin
from .models import Towork
# Register your models here.
admin.site.register(Towork)