from .models import Towork
from django.forms import ModelForm,TextInput
from django.utils.translation import gettext_lazy as _
class ToworkForm(ModelForm):
    class Meta:
        model=Towork
        fields=['name','age','speciality','email','phone','disc']

        
        widgets={
            "name":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Имя'

                
            }),
            "age":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Возраст  от 14 лет',
                'type':'number'
                
            }),
            "speciality":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Ваша специальность(профессия)'
                
            }),
            "email":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Почта',
                'type':'email'
                
            }),
            "phone":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Ваш номер телефона',
                'type':'phone'
            }),
            "disc":TextInput(attrs={
                'class':'form-controll',
                'id':'name-tow',
                'placeholder':'Описание опыта работы и др.',
                
            })

        }
        
        labels={
            'name': _(''),
            'age': _(''),
            'speciality': _(''),
            'email': _(''),
            'phone': _(''),
            'disc': _('')
        }