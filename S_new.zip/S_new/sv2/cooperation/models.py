from django.db import models
from datetime import datetime
# Create your models here.



class Towork(models.Model):
    name=models.TextField('Имя')
    age=models.BigIntegerField('Возраст',max_length=100)
    speciality=models.TextField('Специальность',max_length=300)
    email=models.TextField('Почта',max_length=60)
    phone=models.TextField('Номер',max_length=30)
    disc=models.TextField('Описание работы',max_length=300)
    date=models.DateTimeField('Дата заявки',default=datetime.now)
    istowork=models.BooleanField('Результаты',default='False')
    def __str__(self):
        return self.name