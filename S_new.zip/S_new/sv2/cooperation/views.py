from django.shortcuts import render,redirect
from django.views.generic.edit import CreateView
from .models import Towork
from .forms import ToworkForm
# Create your views here.


def cooperation_home(request):
    form=ToworkForm()
    if request.method=='POST':
        form=ToworkForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request,'coop_p2.html')
    return render(request,'coop_home.html',{'form':form})

def cooperation_p2(request):
    return render(request,'coop_p2.html')
