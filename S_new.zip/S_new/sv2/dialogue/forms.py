from .models import Message
from django.forms import ModelForm,TextInput

class MessageForm(ModelForm):
    class Meta:
        model=Message
        fields=['full_text']
        
        widgets={
            "full_text":TextInput(attrs={
                'class':'form-controll',
                'placeholder':'Сообщениеe'
                
            })
        }
