from django.db import models
from datetime import datetime   
# Create your models here.



class Message(models.Model):
    full_text=models.TextField('')
    fromwho=models.TextField('От кого',default='Нету автора')
    date=models.DateTimeField('Дата сообщения',default=datetime.now)

    def __str__(self):
        return self.full_text