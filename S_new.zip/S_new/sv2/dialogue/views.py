from django.shortcuts import render,redirect
from django.views.generic.edit import CreateView
from .models import Message
from .forms import MessageForm
from datetime import datetime   
# Create your views here.


def home(request):
    return render(request,'home.html')

def discuss(request):
    form=MessageForm()
    if request.method=='POST':
        form=MessageForm(request.POST,initial={"fromwho": request.user.username})
        if form.is_valid():
            form.save()
            return redirect(request.path)
        
    message=Message.objects.order_by('-date')[:50]
    return render(request,'discusstem.html',{'form':form,'message':message})


