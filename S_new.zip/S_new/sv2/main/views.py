from django.shortcuts import render
from django.views.generic.edit import CreateView
from news.models import Articles
from tasks.models import Task
# Create your views here.


def home(request):
    news=Articles.objects.order_by('-data')[:6]
    tasks=Articles.objects.order_by('-data')[:6]
    return render(request,'home.html',{'news':news,'tasks':tasks})

def discuss(request):
    return render(request,'discusstem.html')
