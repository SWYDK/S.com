from django.db import models
from datetime import datetime
# Create your models here.
class Articles(models.Model):
    title=models.CharField('Название',max_length=50)
    
    dis=models.CharField('Описание',max_length=200,default='У этой статьи нету описания')
    full_text=models.TextField('Статья')
    data=models.DateTimeField('Дата публикации',default=datetime.now)


    def __str__(self):
        return self.title
    class Meta:
        verbose_name='Новость'
        verbose_name_plural='Новости'
