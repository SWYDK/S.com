
from django.shortcuts import render
from .models import Articles
# Create your views here.


def p1_news(request):
    news=Articles.objects.order_by('-data')[:12]

    
    return render(request,'p1_newss.html',{'news':news})

def p2_news(request):
    news=Articles.objects.order_by('-data')[:24]
    
    
    return render(request,'p2_newss.html',{'news':news})
