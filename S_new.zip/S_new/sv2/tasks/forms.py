from .models import Task
from django.forms import ModelForm,TextInput

class Otvetid(ModelForm):
    class Meta:
        model=Task
        fields=['otvet']
        
        widgets={
            "otvet":TextInput(attrs={
                'class':'form-controll',
                'placeholder':'ID задачи',
                'name':'q'
                
            })
        }
