from django.db import models
from datetime import datetime
# Create your models here.
class Task(models.Model):
    title=models.CharField('Название',max_length=50)
    otvet=models.TextField('Ответ')
    full_text=models.TextField('Задание')
    data=models.DateTimeField('Дата публикации',default=datetime.now)


    def __str__(self):
        return self.title
    
    class Meta:
        verbose_name='Задача'
        verbose_name_plural='Задачи'
