from django.shortcuts import render,redirect
from django.views.generic.edit import CreateView
from .models import Task
from .forms import Otvetid
# Create your views here.


def p1_tasks(request):

    tasks=Task.objects.order_by('-data')[:27]

    return render(request,'p1_task.html',{"tasks":tasks})


def p2_tasks(request):

    tasks=Task.objects.order_by('-data')

    return render(request,'p2_task.html',{"tasks":tasks})

