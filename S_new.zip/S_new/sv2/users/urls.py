
from django.urls import path,include
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',include('django.contrib.auth.urls')),
    path('profile',views.profile_def,name='profile'),
    path('register/',views.Register.as_view(),name='register'),
]
